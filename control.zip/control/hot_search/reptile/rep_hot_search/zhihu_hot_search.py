# 获取知乎热搜榜前50
from lxml import etree
from hot_search.reptile.common.requests_get import requests_get


# 获取知乎热搜榜单
def zhihu_hot_search(limit=50):
    if limit <= 0:
        limit = 1
    elif limit > 50:
        limit = 50
    url = "https://www.zhihu.com/hot"
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        'cookie': '_zap=a89c70df-d566-45f2-93a1-f0e2318bab9c; d_c0=AKDZ2lQiHxePTka5go1NDXbw5NFmtyxjftU=|1690006365; YD00517437729195%3AWM_TID=phB9iiHQ2QZAEREUABfEh3%2FkC5mbBvBZ; Hm_lvt_98beee57fd2ef70ccdd5ca52b9740c49=1690006367,1690010767,1690029703; _xsrf=f8f7fba0-7b4d-4459-bc5d-00914c13ffbf; YD00517437729195%3AWM_NI=wfzCQqlxoKUh0ZjQDCQvTcxW4MkjY8Afz6acdl7hjdlEdq0KYjBg4LW7t4OIjnQaSUZ%2F8A5IIRqnM%2BbM6eAqmU7lTeTTMAhPUqOvELuVM05RSIktQdLdLsz0s1W5ev6%2BZEQ%3D; YD00517437729195%3AWM_NIKE=9ca17ae2e6ffcda170e2e6ee94c479f5b7b797f56db69a8fb2c55a829a8eadd874b1878fb7e14a9a92ab82dc2af0fea7c3b92ab5bab6a4d47bb0a8a1acd864f486a6b2c74993aa9c84fb5df893a58bdc3483bab6d7e469a8b4f989e970b09bac92b3419bb68e88b74895e9bcd5ce43aab29f82d25f9af1f8a2b8438b8ebf8fd021a293fa86c47baf8bf98dd76f988c83a2eb5c97af8197c848b78a83d1b85a9197a595d47090bc8494f93cb1ef99d6e87ef6f596a6d437e2a3; gdxidpyhxdE=WSko1TE6z3dlwIIzMhmrDHS9xghE3CHoT74GwKuXG%2B4xH6QNbzWgO1f4vL0JmVQ9EgeeBDo0LESx1wGBpfG8QV%2B36MdqB7nw4XKEmW9ygr%5C7B5gVnuk3I9SQH77qZYdUh%2ByuR4OXWOuT30yWBx1AVqV%2B3vievciUU67X2sfEuvHX8mkT%3A1690340602079; captcha_session_v2=2|1:0|10:1690340096|18:captcha_session_v2|88:REk1dE9vK3JGMGxQb09NZVVGMEpJL055UENzUExVQ0FXRU1hNVFZdFJUYTdGNG9HYjMrbjFGM0hPRDRoZzhPdg==|08d2018f26debf44f475c8ce77e779ea1585cf83460853c02755ef4e29accd6c; __snaker__id=rjDMlY7cfTMjDU2v; o_act=login; ref_source=other_https://www.zhihu.com/signin?next=/; expire_in=15552000; q_c1=9b00fb89523f4b158b1659b0843225c3|1690340102000|1690340102000; z_c0=2|1:0|10:1690340105|4:z_c0|92:Mi4xSnk2R0F3QUFBQUFBb05uYVZDSWZGeGNBQUFCZ0FsVk5CdG10WlFEd3FuTzFhWGVPaWpwSXVYaFdNRURPUmNEaFV3|217511e7bd8b642fa5336fcbc3be4cb20cd5cf4a4e6c2200cfbf653eed289d27; SESSIONID=IaepnEG6j9W3ohKFsDRX75yRCdh1NXMA8il97leVD4I; JOID=UV8dAEx4wvO9vKBpLXiSYI3kgnYxNaydydbhIRAW_6uF18wmZM8FPNm8q20iwqlLYclWPH5eR4P2pxSHaj5OgEY=; osd=VV0cBU18wPK4vaRrLH2TZI_lh3c1N62YyNLjIBUX-6mE0s0iZs4APd2-qmgjxqtKZMhSPn9bRof0phGGbjxPhUc=; tst=h; KLBRSID=c450def82e5863a200934bb67541d696|1690354805|1690351580',
    }
    content = requests_get(url,  headers=headers)
    tree = etree.HTML(content)  # 构造一个XPath解析对象并对HTML文本进行自动修正。
    hot_list_title = tree.xpath("//h2[@class='HotItem-title']/text()")[:limit]
    hot_list_value = tree.xpath("//div[@class='HotItem-metrics']/text()")[:limit]
    hot_list_link = tree.xpath("//div[@class='HotItem-content']/a/@href")[:limit]
    hot_list = [{
        "title": a.replace(' ', ''),
        "hot_value": b.replace(' ', '')[:-2],
        "url": c.replace(' ', '')}
        for a, b, c in zip(hot_list_title, hot_list_value, hot_list_link)]
    hot_list = str(hot_list).replace("'", '"')
    # with open('../reptile_static/zhihu_hot_search.json', 'w', encoding='utf-8') as fs:
    #     fs.write(hot_list)
    return hot_list


# if __name__ == '__main__':
#     # 热榜标题 热度值 热搜链接
#     hot_list = zhihu_hot_search(50)
#     print(hot_list)

