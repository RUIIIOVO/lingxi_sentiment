### 文件说明

该包涉及的文件皆使用了爬虫技术，用于获取各大网站热搜榜数据，并在main文件夹中进行汇总并存入数据库。

##### 具体文件说明：

百度：baidu_hot_search.py

哔哩哔哩：bili_hot_search.py

抖音：douyin_hot_search.py

淘宝：toutiao_hot_search.py

微博：weibo_hot_search.py

微信：weixin_hot_search.py

知乎：zhihu_hot_search.py