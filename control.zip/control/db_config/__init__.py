# 数据库连接配置信息
# db = {
#     "host": "127.0.0.1",
#     "port": 3306,
#     "user": "root",
#     "password": "123456",
#     "database": "sentiment"
# }

db = {
    "host": "124.221.178.219",
    "port": 3306,
    "user": "rui",
    "password": "rui123456",
    "database": "lingxi"
}
