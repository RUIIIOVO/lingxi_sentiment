# 获取知乎热搜榜前50
from lxml import etree
from reptile.common.requests_get import requests_get


# 获取知乎热搜榜单
def zhihu_hot_search(limit=50):
    if limit <= 0:
        limit = 1
    elif limit > 50:
        limit = 50
    url = "https://www.zhihu.com/hot"
    # 若无法获取数据且进入登录页，说明cookie已过期，需要更换cookie
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        'cookie': '_zap=a89c70df-d566-45f2-93a1-f0e2318bab9c; d_c0=AKDZ2lQiHxePTka5go1NDXbw5NFmtyxjftU=|1690006365; YD00517437729195%3AWM_TID=phB9iiHQ2QZAEREUABfEh3%2FkC5mbBvBZ; YD00517437729195%3AWM_NI=wfzCQqlxoKUh0ZjQDCQvTcxW4MkjY8Afz6acdl7hjdlEdq0KYjBg4LW7t4OIjnQaSUZ%2F8A5IIRqnM%2BbM6eAqmU7lTeTTMAhPUqOvELuVM05RSIktQdLdLsz0s1W5ev6%2BZEQ%3D; YD00517437729195%3AWM_NIKE=9ca17ae2e6ffcda170e2e6ee94c479f5b7b797f56db69a8fb2c55a829a8eadd874b1878fb7e14a9a92ab82dc2af0fea7c3b92ab5bab6a4d47bb0a8a1acd864f486a6b2c74993aa9c84fb5df893a58bdc3483bab6d7e469a8b4f989e970b09bac92b3419bb68e88b74895e9bcd5ce43aab29f82d25f9af1f8a2b8438b8ebf8fd021a293fa86c47baf8bf98dd76f988c83a2eb5c97af8197c848b78a83d1b85a9197a595d47090bc8494f93cb1ef99d6e87ef6f596a6d437e2a3; q_c1=9b00fb89523f4b158b1659b0843225c3|1690340102000|1690340102000; _xsrf=Hj1ZBjFRIaYMWLQUelRKfNY3FHa0H3BM; z_c0=2|1:0|10:1723087102|4:z_c0|80:MS4xSnk2R0F3QUFBQUFtQUFBQVlBSlZUYi1Hb1dmODZ2UF9SSkUzTHpidnJfRUpYa0hQd0N5QU5BPT0=|410839961e577eb54e063f49c15697175efe45e2a1d3dce9cb0a8718d6709c9b; __zse_ck=001_AJD9ImuLYqbCswx/YAxsrsKuSPrwWl/cqepe9H947tc4RxR5p/jL8VgxsG37oatKv+DXwY9zCSUYU87jgbwr3xwKN5KKj7KdEkWdwzwBdBxJpBxkoOImSpJlRptimTJu; BEC=32377ec81629ec05d48c98f32428ae46; tst=h; SESSIONID=pa8BLzukEbl2JbfbRPlJ51Uu9Y1XsJNTEwMNaqHyWad; JOID=UF4TAU1L26z1UPWDKUuLMMUH15w6P7qQsxiL9kYKvcDDHpPhSy6Ob5NQ8YcpTQ_HvVgB0aC1kiIV4HN3IRCldjc=; osd=UF8VAUJL2qr1X_WCL0uEMMQB15M6PryQvBiK8EYFvcHFHpzhSiiOYJNR94cmTQ7BvVcB0Ka1nSIU5nN4IRGjdjg=',
    }
    content = requests_get(url,  headers=headers)
    tree = etree.HTML(content)  # 构造一个XPath解析对象并对HTML文本进行自动修正。
    hot_list_title = tree.xpath("//h2[@class='HotItem-title']/text()")[:limit]
    hot_list_value = tree.xpath("//div[@class='HotItem-metrics']/text()")[:limit]
    hot_list_link = tree.xpath("//div[@class='HotItem-content']/a/@href")[:limit]
    hot_list = [{
        "title": a.replace(' ', ''),
        "rank": i+1,
        "hot_value": b.replace(' ', '')[:-2],
        "url": c.replace(' ', '')}
        for i, (a, b, c) in enumerate(zip(hot_list_title, hot_list_value, hot_list_link))]
    hot_list = str(hot_list).replace("'", '"')
    return hot_list


if __name__ == '__main__':
    # 热榜标题 热度值 热搜链接
    hot_list = zhihu_hot_search(50)
    print(hot_list)

